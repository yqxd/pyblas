# coding=utf-8
"""
This package hides differences between argparse and optparse.
Use "parser" module as entry point
"""
__author__ = 'Ilya.Kazakevich'
